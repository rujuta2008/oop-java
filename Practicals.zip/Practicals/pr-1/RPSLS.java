import java.util.Scanner;
import java.util.Random;

public class RPSLS {

    enum Move {
        ROCK, PAPER, SCISSORS, LIZARD, SPOCK
    }

    static int winner(Move a, Move b) {

        if (a == b) {
            return 0;
        }

        return switch (a) {
            case ROCK -> (b == Move.SCISSORS || b == Move.LIZARD) ? 1 : -1;
            case PAPER -> (b == Move.ROCK || b == Move.SPOCK) ? 1 : -1;
            case SCISSORS -> (b == Move.PAPER || b == Move.LIZARD) ? 1 : -1;
            case LIZARD -> (b == Move.SPOCK || b == Move.PAPER) ? 1 : -1;
            case SPOCK -> (b == Move.SCISSORS || b == Move.ROCK) ? 1 : -1;
        };
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        Move[] moves = Move.values();

        int playerScore = 0;
        int computerScore = 0;

        for (int round = 1; round <= 5; round++) {

            System.out.println("Round " + round);

            System.out.print("Enter move (ROCK, PAPER, SCISSORS, LIZARD, SPOCK): ");
            Move player = Move.valueOf(sc.next().toUpperCase());

            Move computer = moves[random.nextInt(moves.length)];

            System.out.println("You: " + player);
            System.out.println("Computer: " + computer);

            int result = winner(player, computer);

            if (result == 1) {
                System.out.println("Round winner: You");
                playerScore++;
            }
            else if (result == -1) {
                System.out.println("Round winner: Computer");
                computerScore++;
            }
            else {
                System.out.println("Round winner: Tie");
            }
        }
  
        System.out.println("Final Score: You " + playerScore + " - " + computerScore);

        if (playerScore > computerScore) {
            System.out.println("You win " + playerScore + "–" + computerScore);
        }
        else if (computerScore > playerScore) {
            System.out.println("Computer wins " + computerScore + "–" + playerScore);
        }
        else {
            System.out.println("Overall result: Tie");
        }

        sc.close();
    }
}