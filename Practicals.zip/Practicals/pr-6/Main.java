import java.util.Scanner;

@FunctionalInterface
interface DiscountRule {
    double apply(double price);
}

class DiscountEngine {

    private final DiscountRule rule;

    public DiscountEngine(DiscountRule rule) {
        this.rule = rule;
    }

    public double apply(double price) {
        return rule.apply(price);
    }
}

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        double[] prices = {
            1000,
            2000,
            500,
            1500
        };

        System.out.println("1. 10% discount");
        System.out.println("2. 20% discount");
        System.out.println("3. No discount");

        System.out.print("Choose discount rule: ");
        int choice = sc.nextInt();

        DiscountRule rule;

        switch (choice) {

            case 1:
                rule = price -> price * 0.90;
                break;

            case 2:
                rule = price -> price * 0.80;
                break;

            case 3:
                rule = price -> price;
                break;

            default:
                System.out.println("Invalid choice");
                sc.close();
                return;
        }

        DiscountEngine engine = new DiscountEngine(rule);

        double total = 0;

        for (double price : prices) {

            double finalPrice = engine.apply(price);

            System.out.println(
                "Original: " + price +
                " Final: " + finalPrice
            );

            total += finalPrice;
        }

        System.out.println("Total after discount: " + total);

        sc.close();
    }
}
