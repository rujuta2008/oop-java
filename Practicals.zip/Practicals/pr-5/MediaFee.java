abstract class Media {

    String title;
    int lateDays;

    Media(String title, int lateDays) {
        this.title = title;
        this.lateDays = lateDays;
    }

    abstract double lateFee();

    String getTitle() {
        return title;
    }
}

class Book extends Media {

    Book(String title, int lateDays) {
        super(title, lateDays);
    }

    double lateFee() {
        return lateDays * 2.0;
    }
}

class Movie extends Media {

    Movie(String title, int lateDays) {
        super(title, lateDays);
    }

    double lateFee() {
        return lateDays * 5.0;
    }
}

class Game extends Media {

    Game(String title, int lateDays) {
        super(title, lateDays);
    }

    double lateFee() {
        return lateDays * 10.0;
    }
}

public class MediaFee {

    public static void main(String[] args) {

        Media[] returnedMedia = {

            new Book("Java Basics", 3),
            new Movie("Inception", 2),
            new Game("Chess", 4),
            new Book("OOP Guide", 1)
        };

        double totalFee = 0;

        for (Media media : returnedMedia) {

            double fee = media.lateFee();

            System.out.println(
                media.getTitle() +
                " Late Fee: " +
                fee
            );

            totalFee += fee;
        }

        System.out.println("Total Late Fee: " + totalFee);
    }
}
