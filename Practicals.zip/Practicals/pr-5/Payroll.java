abstract class Employee {
    String name;
    int id;

    Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }

    abstract double monthlySalary();
}

class FullTime extends Employee {
    double salary;

    FullTime(String name, int id, double salary) {
        super(name, id);
        this.salary = salary;
    }

    double monthlySalary() {
        return salary;
    }
}

class PartTime extends Employee {
    int hours;
    double rate;

    PartTime(String name, int id, int hours, double rate) {
        super(name, id);
        this.hours = hours;
        this.rate = rate;
    }

    double monthlySalary() {
        return hours * rate;
    }
}

class Intern extends Employee {
    double stipend;

    Intern(String name, int id, double stipend) {
        super(name, id);
        this.stipend = stipend;
    }

    double monthlySalary() {
        return stipend;
    }
}

public class Payroll {
    public static void main(String[] args) {

        Employee[] employees = {
            new FullTime("Riya", 101, 50000),
            new PartTime("Amit", 102, 80, 300),
            new Intern("Neha", 103, 15000),
            new FullTime("Rahul", 104, 60000),
            new PartTime("Karan", 105, 60, 250)
        };

        double total = 0;

        for (Employee e : employees) {

            double salary = e.monthlySalary();

            System.out.println(
                e.name + " (ID: " + e.id + ") Salary: " + salary
            );

            if (e instanceof Intern) {
                System.out.println("Note: This employee is an Intern.");
            }

            total = total + salary;
        }

        System.out.println("Total Salary: " + total);
    }
}
